import { LightningElement,api } from 'lwc';
export default class LeadListItem extends LightningElement {
@api lead;

}